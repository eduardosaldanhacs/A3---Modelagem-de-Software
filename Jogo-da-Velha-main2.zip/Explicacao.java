public class Explicacao {
    //Atributos:
    private String Explicacao;

    public Explicacao (String Explicacao) {
        this.Explicacao = Explicacao;
    }

    public String getExplicacao() {
        return Explicacao;
    }

    public void setExplicacao(String Explicacao) {
        this.Explicacao = Explicacao;
    }

}
